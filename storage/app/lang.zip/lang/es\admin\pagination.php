<?php

return [
    'previous' => '&laquo; Anterior',
    'next' => 'Próximo &raquo;',
    'record_desc' => 'Mostrando :first_item a :last_item de :total entradas',
];
