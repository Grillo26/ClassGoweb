<?php

return [
    'per_page' => 'لكل صفحة',
    'previous' => 'السابق',
    'next' => 'التالي',
    'show' => 'عرض',
    'listing_per_page' => 'قوائم لكل صفحة',
];
