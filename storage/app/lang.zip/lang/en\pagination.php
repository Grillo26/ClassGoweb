<?php

return [
    'per_page' => 'Per page',
    'previous' => 'Previous',
    'next' => 'Next',
    'show' => 'Show',
    'listing_per_page' => 'listings per page',
];
