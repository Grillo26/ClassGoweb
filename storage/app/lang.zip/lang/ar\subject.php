<?php

return [
    'select_all_subject_groups' => 'اختر جميع المجموعات',
    'subject_title' => 'المواد التي يمكنني تدريسها',
    'subject_title_desc' => 'يرجى تقديم خلفيتك التعليمية لمساعدتنا في تقييم مؤهلاتك.',
    'hourly_rate' => 'السعر لكل ساعة:',
    'choose_subject_category' => 'اختر فئة المادة التي يمكنك تدريسها',
    'edit_subject' => 'تحرير المادة',
    'add_subject' => 'إضافة مادة',
    'choose_subject' => 'اختر المادة التي يمكنك تدريسها',
    'select_subject' => 'اختر مادة',
    'session_price' => 'سعر الجلسة',
    'breif_introduction' => 'مقدمة مختصرة',
    'add_introduction' => 'أضف مقدمتك',
    'add_new_subject' => 'إضافة مادة جديدة',
    'add_subject_group' => 'إضافة مجموعة مواد',
    'subject_group' => 'مجموعة المواد',
    'choose_subject_group' => 'اختر مجموعة المواد',
    'choose_subject_label' => 'اختر مادة',
];
