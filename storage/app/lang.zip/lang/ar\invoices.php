<?php

return [
    'invoices' => 'الفواتير',
    'filter_by' => 'تصفية حسب:',
    'all_invoices' => 'جميع الفواتير',
    'pending' => 'قيد الانتظار',
    'complete' => 'مكتمل',
];
