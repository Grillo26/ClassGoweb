<?php

return [
    'translation' => 'agregas traducción aquí',
];
