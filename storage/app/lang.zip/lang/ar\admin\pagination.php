<?php

return [
    'previous' => 'السابق &laquo;',
    'next' => 'التالي &raquo;',
    'record_desc' => 'عرض :first_item إلى :last_item من :total مدخلات',
];
