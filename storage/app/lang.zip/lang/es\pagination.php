<?php

return [
    'per_page' => 'Por página',
    'previous' => 'Anterior',
    'next' => 'Próximo',
    'show' => 'Mostrar',
    'listing_per_page' => 'listados por página',
];
