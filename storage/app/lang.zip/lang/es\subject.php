<?php

return [
    'select_all_subject_groups' => 'Seleccionar todo el grupo',
    'subject_title' => 'Materias que puedo enseñar',
    'subject_title_desc' => 'Proporcione su formación académica para ayudarnos a evaluar sus calificaciones.',
    'hourly_rate' => 'Tarifa por hora:',
    'choose_subject_category' => 'Elija la categoría de materia que puede enseñar',
    'edit_subject' => 'Editar Asunto',
    'add_subject' => 'Agregar Asunto',
    'choose_subject' => 'Elige la materia que puedes enseñar',
    'select_subject' => 'Seleccione un tema',
    'session_price' => 'Precio de la sesión',
    'breif_introduction' => 'Una breve introducción',
    'add_introduction' => 'Añade tu introducción',
    'add_new_subject' => 'Agregar nuevo tema',
    'add_subject_group' => 'Agregar grupo de temas',
    'subject_group' => 'Grupo de materias',
    'choose_subject_group' => 'Elige grupo de materias',
    'choose_subject_label' => 'Elige tema',
];
