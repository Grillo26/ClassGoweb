<?php

return [
    'previous' => '&laquo; Previous',
    'next' => 'Next &raquo;',
    'record_desc' => 'Showing :first_item to :last_item of :total entries',
];
