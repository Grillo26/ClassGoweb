<?php

return [
    'title' => 'العنوان',
    'student_name' => 'اسم الطالب',
    'tutor_name' => 'اسم المعلم',
    'amount' => 'المبلغ',
    'tutor_payout' => 'دفع المعلم',
    'status' => 'الحالة',
    'subject' => 'الموضوع',
    'subject_group' => 'مجموعة الموضوعات',
    'id' => '#رقم الطلب',
    'transaction_id' => 'رقم المعاملة',
    'all_bookings' => 'جميع الحجوزات',
    'pending' => 'قيد الانتظار',
    'complete' => 'مكتمل',
    'select_subject' => 'اختر الموضوع',
    'select_subject_group' => 'اختر مجموعة الموضوعات',
    'date' => 'التاريخ',
];
