<?php

return [
    'translation' => 'أضف الترجمة هنا',
];
