<?php

return [
    'invoices' => 'Invoices',
    'filter_by' => 'Filter by:',
    'all_invoices' => 'All Invoices',
    'pending' => 'Pending',
    'complete' => 'Complete',
    'preview' => 'Preview',
    'invoice_title' => 'Title',
    'invoice_bill_to' => 'Bill To',
    'invoice_student_name' => 'Student Name',
    'invoice_address' => 'Address',
    'invoice_email' => 'Email',
    'invoice_id' => 'ID',
    'invoice_qty' => 'Qty.',
    'invoice_price' => 'Price',
    'invoice_subtotal' => 'Subtotal',
    'invoice_total' => 'Total',
    'invoice_discount_code' => 'Discount Code',
    'invoice_discount_amount' => 'Discount Amount',
];
